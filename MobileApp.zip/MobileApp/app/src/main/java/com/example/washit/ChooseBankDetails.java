package com.example.washit;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ChooseBankDetails extends AppCompatActivity {
    Connection connection = null;
    Statement statement = null;
    ArrayList<BankDetails> bankDetailsList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_bank_details);

        try {
            Toast.makeText(this, connectDB(), Toast.LENGTH_SHORT).show();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        String query = "SELECT * FROM BankDetails;";
        try {
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()){
                int AccountNo = resultSet.getInt("AccountNo");
                String BankName = resultSet.getString("BankName");
                int CardNumber = resultSet.getInt("CardNumber");
                int BranchCode = resultSet.getInt("BranchCode");
                int cvv = resultSet.getInt("CVV");
                int BankID = resultSet.getInt("BankID");
                int StudentNo = resultSet.getInt("StudentNo");
                BankDetails bankDetails = new BankDetails(AccountNo,BankName,CardNumber,BranchCode,cvv,BankID,StudentNo);
                bankDetailsList.add(bankDetails);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        ArrayAdapter<BankDetails> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,
                android.R.id.text1,
                bankDetailsList);

        ListView lstOfBanks = findViewById(R.id.listOfBankingDetails);
        TextView txtNoBanks = findViewById(R.id.txtResults);
        if(adapter.getCount()<1){
            txtNoBanks.setText(R.string.noBanks);
        }
        else{
            lstOfBanks.setAdapter(adapter);
           // lstOfBanks.setOnItemSelectedListener(new AdapterView.OnItemClickListener() {
//                @Override
//                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//
//                    String selectedItem = parent.getItemAtPosition(position).toString();
//                    Toast.makeText(getApplicationContext(), "Clicked: " + selectedItem, Toast.LENGTH_SHORT).show()
//                }
            //});
        }
    }
    public void onBtnAddNewClicked(View view){
        Intent intent = new Intent(this,MakeOnlinePayment.class);
        startActivity(intent);
    }
    private String connectDB() throws SQLException {
        String result = null;
        Log.d("database","debugging");
        try {
            // Connect to the database
            connection = DatabaseManager.getConnection();

            if (connection != null) {
                statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);

                result = "Connection successful!";
            } else {
                result = "Connection failed!";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            result = "Connection error: " + e.getMessage();
        } finally {
            // Close the resources

        }

        return result;
    }
}