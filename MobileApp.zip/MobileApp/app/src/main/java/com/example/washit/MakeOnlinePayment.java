package com.example.washit;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

public class MakeOnlinePayment extends AppCompatActivity {

    ArrayList<Item> selectedItems = new ArrayList<>();
    private Bundle extras;

    Connection connection = null;
    Statement statement = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_make_online_payment);

        Intent intent = getIntent();
        if(intent !=null){
            extras = intent.getExtras();

            if(extras!=null){
                selectedItems = (ArrayList<Item>) extras.getSerializable("SelectedItems");
            }else{

            }
        }
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void onBtnPayClicked(View view) throws SQLException {
        connectDB();
        createDeliveryRecord();
        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("Laundry Order Placed");
        alertDialog.setMessage(getString(R.string.successMessage));
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Done",
                (dialogInterface, i) -> {
                    dialogInterface.dismiss();
                    finish();
                });
        alertDialog.show();
    }
    public void onBtnSaveClicked(View view) throws SQLException {

        EditText bankName = findViewById(R.id.txtBankName);
        EditText accNumber = findViewById(R.id.txtAccountNumber);
        EditText branchCode = findViewById(R.id.txtBranchCode);
        EditText cardNumber = findViewById(R.id.txtCardNumber);
        EditText cvvNo = findViewById(R.id.txtCvvNumber);

        String bName = bankName.getText().toString();
        String aNumber = accNumber.getText().toString();
        String bCode = branchCode.getText().toString();
        String cNumber = cardNumber.getText().toString();
        String cvv = cvvNo.getText().toString();
        int studentNo = 254953665;

        String result = connectDB();
        String query = "INSERT INTO BankDetails (AccountNo, BankName, CardNumber, BranchCode, CVV,StudentNo)\n" +
                "VALUES ('"+ aNumber + "','" +bName+"', '"+cNumber +"', '"+ bCode+"', '"+cvv +"','"+studentNo+"');";
        statement.execute(query);
        try {
            if (statement != null)
                statement.close();
            if (connection != null)
                connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void createLaundryBasketRecord(int OrderNumber) throws SQLException {

        double Total = 0;
        int Quantity = 0;
        int ItemID = 0;
        for(Item item:selectedItems){
            ItemID = item.getItemId();
            Quantity = item.getQuantity();
            Total = Quantity*item.getItemPrice();
            String query = "INSERT INTO LaundryBasket(Quantity,TotalPrice,ItemID,OrderNumber)"+"\n"
                    +"VALUES('"+Quantity+"','"+Total+"','"+ItemID+"','"+OrderNumber+"');";
            statement.execute(query);
        }
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void createLaundryOrderRecord(int DeliveryID) throws SQLException {

        LocalDate currentDate = LocalDate.now();
        String DataPlaced = currentDate.toString();
        String DateTaken = "not Taken";
        int StudentNo = 220106495;

        int EmployeeID = 24521365;
        String LaundryStatus = "On Delivery";

        String query = "INSERT INTO LaundryOrder(DatePlaced,DateTaken,StudentNo,DeliveryID,EmployeeID,LaundryStatus)"+"\n"
                +"VALUES('"+DataPlaced+"','"+DateTaken+"','"+StudentNo+"','"+DeliveryID+"','"+EmployeeID+"','"+LaundryStatus+"');";
        statement.execute(query,Statement.RETURN_GENERATED_KEYS);

        ResultSet set = statement.getGeneratedKeys();
        set.next();
        int OrderNumber = set.getInt(1);
        createLaundryBasketRecord(OrderNumber);

    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void createDeliveryRecord() throws SQLException {
        int empId = 1;
        double cost = 0;
        String query = "INSERT INTO Delivery(EmployeeID,Cost)"+"\n"
                +"VALUES('1','0');";

        statement.execute(query,Statement.RETURN_GENERATED_KEYS);

        ResultSet set = statement.getGeneratedKeys();
        set.next();
        int DeliveryID = set.getInt(1);
        createLaundryOrderRecord(DeliveryID);

    }

    private String connectDB() throws SQLException {
        String result = null;
        Log.d("database","debugging");
        try {
            // Connect to the database
            connection = DatabaseManager.getConnection();

            if (connection != null) {
                statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);

                result = "Connection successful!";
            } else {
                result = "Connection failed!";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            result = "Connection error: " + e.getMessage();
        } finally {
            // Close the resources

        }

        return result;
    }
}