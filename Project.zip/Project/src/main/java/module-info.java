module com.example.project {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires java.sql;
    requires java.mail;

    opens com.example.project to javafx.fxml;
    exports com.example.project;
}